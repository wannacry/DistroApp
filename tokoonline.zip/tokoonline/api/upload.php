<?php
error_reporting(0);
require("koneksi.php");

$response = array();
 
 if (empty($_POST['jumlah']) || empty($_POST['bank']) || empty($_POST['nama'])) {
 
   $response["success"]= 0;
    $response["message"] = "Pastikan semua data terisi";

   
    echo json_encode($response);	
	}else {

    
    $jumlah = $_POST['jumlah'];
	$bank = $_POST['bank'];
	$nama = $_POST['nama'];
	
	$cek_idp=mysql_query("SELECT * FROM tbl_konfirmasi WHERE jumlah = '$jumlah'");
	if (mysql_num_rows($cek_idp) > 0) {
	$response["success"] = 0;
    $response["message"]= "Order sudah dikonfirmasi.";
	echo json_encode($response);
     }
	 if (mysql_num_rows($cek_email) == 0) {
	
	$result = mysql_query("INSERT INTO tbl_konfirmasi(bank, nama, jumlah) VALUES('$bank', '$nama', '$jumlah' )");
    
    if ($result) {
		//mysql_query("UPDATE pesan SET status = '$_POST[status]' WHERE idp = '$_POST[id_pesan]'");
        
       $response["success"] = 1;
       $response["message"] = "Berhasil menyimpan data.";
	   
	  	//mengirim email peringatan pemesanan kepada admin
		$to = "demoonlineku@gmail.com";
		$subject = "Notifikasi Konfirmasi Baru";
		$message = "Monggo cek di Admin Panel";
		$from = "demoonlineku@gmail.com";
		$headers = "From:" . $from;
		mail($to,$subject,$message,$headers);

        
        echo json_encode($response);
    } else {
        
        $response["success"] = 0;
        $response["message"]= "Gagal menambah data.";
        
       
        echo json_encode($response);
  } 
  }}
  