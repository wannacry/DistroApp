<?php
error_reporting(0);
require("koneksi.php");

//buat array untuk menampung respon dari JSON
$respon = array();


// cek apakah nilai yang dikirimkan android sudah terisi
 if (isset($_POST['idorder']) && isset($_POST['username'])) {
 $idorder = $_POST['idorder'];
 $username = $_POST['username'];

// query ambil data member berdasarkan idproduk dan id sesi
    $result = mysql_query("SELECT D.*, P.*,C.*,O.*,B.* FROM tbl_order_detail D, tbl_produk P, tbl_kustomer C, tbl_order O, tbl_kecamatan B where D.id_produk=P.id_produk and D.id_order='$idorder' and C.id_order='$idorder' and O.id_order='$idorder' and O.id_kecamatan=B.id_kecamatan and O.username=D.username and O.username='$username'") or die(mysql_error());
	
	
    if (!empty($result)) {
        // jika data jadwal ada (besar dari nol)
        if (mysql_num_rows($result) > 0) {
		$subtotal =0;
		$berat = 0;
		$ongkir =0;
		// node keranjang
            $respon["trans"] = array();
            while($row = mysql_fetch_array($result)) {
			
			$total_harga = $row["harga"] * $row["jumlah"];
			$subtotal=$subtotal+$total_harga;
			$berat = $berat + $row["berat"]*$row[jumlah];
			
			$nama = $row["nama_lengkap"];
		   	$alamat = $row["alamat"];
			$telpon = $row["telpon"];
			$idorder = $row["id_order"];
			$ongkir = $row["ongkir"];
			$uncode = $row["un_code"];
			
			// temp keranjang array
            $trans = array();
			$trans["id_produk"] = $row["id_produk"];
			$trans["username"] =  $_POST['username'];
			$trans["nama_produk"] =  $row["nama_produk"];
            $trans["qty"] = $row["jumlah"];
			$trans["harga"] = $row["harga"];
			$trans["totharga"] = $total_harga;
			          
			//tambahkan array $jadwal pada array final $respon
            array_push($respon["trans"], $trans);
			}
			// sukses
            $respon["subtotal"] = $subtotal;
			$respon["sukses"] = 1;
			$respon["berat"] = ceil($berat);
			$respon["ongkir"] = $respon["berat"] * $ongkir ;
			$respon["nama"] = $nama;
			$respon["alamat"] = $alamat;
			$respon["telpon"] = $telpon;
			$respon["idorder"] = $idorder;
			$respon["uncode"] = $uncode;
			$respon["grandtotal"]= $respon["subtotal"] + $respon["ongkir"];

            // memprint/mencetak JSON respon
            echo json_encode($respon);
        } else {
            // tidak ada keranjang (kecil dari nol)
            $respon["sukses"] = 0;
            $respon["pesan"] = "Detail Transaksi Kosong";

            // memprint/mencetak JSON respon
            echo json_encode($respon);
        }
    } else {
        // jika query tidak tidak menghasilkan data (tidak ada member)
        $respon["sukses"] = 0;
        $respon["pesan"] = "Gagal Query";

        // memprint/mencetak JSON respon
        echo json_encode($respon);
    }
} else {
    // jika data tidak terisi/tidak terset
    $respon["sukses"] = 0;
    $respon["pesan"] = "data json tidak terkirim";

    // memprint/mencetak JSON respon
    echo json_encode($respon);
}
?>
<h1>Cari Keranjang</h1> 
	<form action="cetaktransaksi.php" method="post"> 
	    id sesi:<br /> 
	    <input type="text" name="idsesi" value="" /> 
	    <br /><br /> 
		   
	    <input type="submit" value="Cari" /> 
	</form>
