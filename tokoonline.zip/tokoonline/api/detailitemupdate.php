<?php
error_reporting(0);
require("koneksi.php");

//buat array untuk menampung respon dari JSON
$respon = array();


// cek apakah nilai yang dikirimkan android sudah terisi
 if (isset($_POST['id_produk']) && isset($_POST['username'])&& isset($_POST['idorder'])) { 

 $id_produk = $_POST['id_produk'];
 $username = $_POST['username'];
 $idorder = $_POST['idorder'];


// query ambil data member berdasarkan idproduk dan id sesi
    $result = mysql_query("SELECT * FROM tbl_order INNER JOIN tbl_order_detail ON tbl_order.id_order = tbl_order_detail.id_order 
INNER JOIN tbl_produk ON tbl_produk.id_produk = tbl_order_detail.id_produk 
WHERE tbl_order.username='$username' AND tbl_order.ket ='1' AND tbl_order_detail.id_order='$idorder'
AND tbl_order_detail.id_produk = '$id_produk'") or die(mysql_error());
	
	
    if (!empty($result)) {
        // jika data jadwal ada (besar dari nol)
        if (mysql_num_rows($result) > 0) {
		// node keranjang
            $respon["item"] = array();
            $row = mysql_fetch_array($result);

			// temp keranjang array
            $item = array();
			$item["id_produk"] = $row["id_produk"];
			$item["username"] =  $_POST['username'];
			$item["nama"] =  $row["nama_produk"];
			$item["idorder"] =  $row["id_order"];
            $item["qty"] = $row["jumlah"];
			$item["harga"] = $row["harga"];
			$item["gambar"] = "http://192.168.43.96/tokoonline/$row[gambar_produk]";
          
			//tambahkan array $jadwal pada array final $respon
            array_push($respon["item"], $item);
			// sukses
			$respon["sukses"] = 1;
			 
            // memprint/mencetak JSON respon
            echo json_encode($respon);
        } else {
            // tidak ada member (kecil dari nol)
            $respon["sukses"] = 0;
            $respon["pesan"] = "ID Tidak Terset";

            // memprint/mencetak JSON respon
            echo json_encode($respon);
        }
    } else {
        // jika query tidak tidak menghasilkan data (tidak ada member)
        $respon["sukses"] = 0;
        $respon["pesan"] = "Gagal Query";

        // memprint/mencetak JSON respon
        echo json_encode($respon);
    }
} else {
    // jika data tidak terisi/tidak terset
    $respon["sukses"] = 0;
    $respon["pesan"] = "data json tidak terkirim";

    // memprint/mencetak JSON respon
    echo json_encode($respon);
}
?>
<h1>Cari Keranjang</h1> 
	<form action="detailitemproduk.php" method="post"> 
	    id order:<br /> 
	    <input type="text" name="idorder" value="" /> 
	    <br /><br /> 
		  	    idproduk:<br /> 
	    <input type="text" name="idproduk" value="" /> 
	    <br /><br />  
	    <input type="submit" value="Cari" /> 
	</form>
