<?php
error_reporting(0);
include 'koneksi.php';
date_default_timezone_set('Asia/Jakarta');

$respon = array();

if (isset($_POST['id_produk']) && isset($_POST['username'])) {
   
    $id_produk= $_POST['id_produk'];
	$username = $_POST['username'];
	$jam = date("H:i:s");
	$tanggal = date("Y-m-d");
	$jumlah=1;

	$cari = mysql_query("SELECT * from tbl_order where username='$username' and ket='1'") or die(mysql_error());
	
        if (mysql_num_rows($cari) <= 0) {
		$result = mysql_query("INSERT INTO tbl_order (tgl_order, jam_order, username, ket) VALUES ('$tanggal','$jam','$username','1')");
		if ($result) {
 
        $respon["sukses"] = 1;
        $respon["pesan"] = "Berhasil update item belanja.";

        echo json_encode($respon);
    } else {
       
        $respon["sukses"] = 0;
        $respon["pesan"] = "Gagal update item belanja.";
        
        echo json_encode($respon);
    }
  }
}

?>
<h1>Tambah Keranjang</h1> 
	<form action="insert.php" method="post"> 
	    id produk:<br /> 
	    <input type="text" name="id_produk" value="" /> 
	    <br /><br /> 
		username:<br /> 
	    <input type="text" name="username" value="" /> 
	    <br /><br />   
	    <input type="submit" value="Cari" /> 
	</form>
