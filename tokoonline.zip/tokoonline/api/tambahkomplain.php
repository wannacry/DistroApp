<?php
error_reporting(0);
include 'koneksi.php';
date_default_timezone_set('Asia/Jakarta');

$respon = array();

// cek apakah nilai yang dikirimkan android sudah terisi
if (isset($_POST['nama']) && isset($_POST['email']) && isset($_POST['komplain']) && isset($_POST['username'])) {
    
    $nama = $_POST['nama'];
    $email = $_POST['email'];
	$komplain = $_POST['komplain'];
	$username = $_POST['username'];
	$tanggal = date("Y-m-d");

      // query menambah data member
    $result = mysql_query("INSERT INTO tbl_komplain(nama, email, tanggal, pesan, username) VALUES('$nama', '$email', '$tanggal', '$komplain' , '$username')");

    // cek apakah query berhasil menambah data
    if ($result) {
        // jika berhasil menambah data ke mysql
        $respon["sukses"] = 1;
        $respon["pesan"] = "Berhasil menambah data.";

        // memprint/mencetak JSON respon
        echo json_encode($respon);
    } else {
        // gagal menambah data member
        $respon["sukses"] = 0;
        $respon["pesan"] = "Gagal menambah data.";
        
        // memprint/mencetak JSON respon
        echo json_encode($respon);
    }
} else {
    // jika data tidak terisi/tidak terset
    $respon["sukses"] = 0;
    $respon["pesan"] = "data belum terisi";

    //  memprint/mencetak JSON respon
    echo json_encode($respon);
}
?>