<?php
error_reporting(0);
require("koneksi.php");

	$response = array();
    $response["kabupaten"] = array();
	
	$id_prop = $_GET['id_prop'];
    
    // Mysql select query
    $result = mysql_query("SELECT * FROM tbl_kabupaten WHERE id_provinsi='$id_prop'");
    
    while($row = mysql_fetch_array($result)){
        // temporary array to create tujuan
        $kab = array();
        $kab["id"] = $row["id_kabupaten"];
        $kab["kabupaten"] = $row["nama_kabupaten"];
        
        // push category to final json array
        array_push($response["kabupaten"], $kab);
    }
    
    // keeping response header to json
    header('Content-Type: application/json');
    
    // echoing json result
	echo json_encode($response); 
	
	?>