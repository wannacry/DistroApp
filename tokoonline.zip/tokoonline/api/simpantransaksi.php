<?php
error_reporting(0);
include 'koneksi.php';
date_default_timezone_set('Asia/Jakarta');

$unik = mt_rand(125, 455);
echo mt_rand(255, 355);
echo"<br/>";
echo $unik;


$respon = array();

// cek apakah nilai yang dikirimkan android sudah terisi
if (isset($_POST['username']) && isset($_POST['namapel']) && isset($_POST['alamatpel'])&& isset($_POST['telponpel']) && isset($_POST['id_kecamatan'])) {
    
	$username = $_POST['username'];
	//$idorder = $_POST['idorder'];
    $nama= $_POST['namapel'];
	$alamat= $_POST['alamatpel'];
	$telpon= $_POST['telponpel'];
	$id_kecamatan= $_POST['id_kecamatan'];
	$jam = date("H:i:s");
	$tanggal = date("Y-m-d");
	
	$pencarian = mysql_query("SELECT * from tbl_order where username='$username' and ket='1'") or die(mysql_error()); 
	 if (mysql_num_rows($pencarian) > 0) {
		 while($row = mysql_fetch_array($pencarian)) {
		 $idorder = $row["id_order"];
		}
	}
	
      // query menambah data pelanggan
    $result_pel = mysql_query("INSERT INTO tbl_kustomer(nama_lengkap, alamat, telpon, id_order, username, un_code) VALUES ('$nama', '$alamat','$telpon', '$idorder', '$username', '$unik')");

    // cek apakah query berhasil menambah data
    if ($result_pel) {
        // jika berhasil menambah data ke mysql
        $respon["sukses"] = 1;
        $respon["pesan"] = "Berhasil menambah data pelanggan.";
		
		//mengirim email peringatan pemesanan kepada admin
		$to = "demoonlineku@gmail.com";
		$subject = "Notifikasi Pemesanan Baru";
		$message = "Monggo cek di Admin Panel";
		$from = "andridarmawan@gmail.com";
		$headers = "From:" . $from;
		mail($to,$subject,$message,$headers);
        // memprint/mencetak JSON respon
			
        echo json_encode($respon);
		
    } else {
        // gagal menambah data member
        $respon["sukses"] = 0;
        $respon["pesan"] = "Gagal menambah data pelanggan.";
        
        // memprint/mencetak JSON respon
        echo json_encode($respon);
    }

	//cari_keranjang
	$cari_keranjang = mysql_query("SELECT * from tbl_order where username='$username' and id_order='$idorder' and ket='1'") or die(mysql_error()); 
	if (mysql_num_rows($cari_keranjang) > 0) {
	 while($row = mysql_fetch_array($cari_keranjang)) {

		$username = $row["username"];
		$idorder = $row["id_order"];
	
	$result_orders = mysql_query("UPDATE tbl_order SET status_order ='Belum', id_kecamatan = '$id_kecamatan', ket= '0' WHERE username = '$username' 
		AND id_order = '$idorder'");
		}	
	
	}	
	
	 $stok = mysql_query("SELECT * from tbl_order_detail where username='$username' and id_order='$idorder'") or die(mysql_error()); 
	if (mysql_num_rows($stok) > 0) {
	 while($row = mysql_fetch_array($stok)) {
	 $id_produk = $row["id_produk"];
	 $jumlah = $row["jumlah"];
	 $username = $row["username"];
	 $idorder = $row["id_order"];
	 
	 $stokup = mysql_query("UPDATE tbl_produk SET stok=stok-'$jumlah' WHERE id_produk='$id_produk'");
	}
	}	
	
}

?>
<h1>Simpan Keranjang</h1> 
	<form action="simpantransaksi.php" method="post"> 

		username:<br /> 
	    <input type="text" name="username" value="" /> 
	    <br /><br />   
		nama:<br /> 
		<input type="text" name="namapel" value="" /> 
	    <br /><br />  
		alamat:<br /> 
		<input type="text" name="alamatpel" value="" /> 
	    <br /><br />  
	     telpon:<br /> 
		 <input type="text" name="telponpel" value="" /> 
	    <br /><br />  
		id_kecamatan:<br /> 
		 <input type="text" name="id_kecamatan" value="" /> 
	    <br /><br /> 
	    <input type="submit" value="Cari" /> 
	</form>
