<?php
error_reporting(0);
require("koneksi.php");

$response = array();

 
if (isset($_POST['username']) && isset($_POST['password'])) {
    
    $username = $_POST['username'];
    $password = $_POST['password'];

    
    $result = mysql_query("SELECT * FROM tbl_member WHERE username = '$username' AND password= '$password'");

     if (!empty($result)) {
		if (mysql_num_rows($result) > 0) {
        
        $response["success"] = 1;
         $response["message"] = "Login Berhasil.";
        
         
        echo json_encode($response);
    	} if (mysql_num_rows($result) == 0)  {
		 
         $response["success"]  = 0;
        $response["message"]= "Gagal login, username atau password salah atau belum terisi.";
        
         
        echo json_encode($response);
    }
  }

} 

?>

<h1>Login</h1> 
		<form action="login.php" method="post"> 
		    Username:<br /> 
		    <input type="text" name="username" placeholder="username" /> 
		    <br /><br /> 
		    Password:<br /> 
		    <input type="password" name="password" placeholder="password" value="" /> 
		    <br /><br /> 
		    <input type="submit" value="Login" /> 
		</form> 

		