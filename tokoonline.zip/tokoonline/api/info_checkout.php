<?php
error_reporting(0);
require("koneksi.php");

$respon = array();

if (isset($_GET["username"]) && isset($_GET["idorder"])) {
    $username = $_GET['username'];
	$idorder = $_GET['idorder'];

    $result = mysql_query("SELECT k.nama_lengkap, k.alamat, k.un_code, o.id_order, d.id_produk, d.jumlah, p.*, c.*  
FROM tbl_kustomer k, tbl_order o, tbl_order_detail d, tbl_produk p, tbl_kecamatan c 
WHERE p.id_produk=d.id_produk AND o.id_kecamatan = c.id_kecamatan AND o.id_order = d.id_order AND o.id_order='$idorder'
AND k.id_order = d.id_order");

    if (!empty($result)) {
	
        if (mysql_num_rows($result) > 0) {
		
			$subtotal =0;
			$berat = 0;
			$ongkir =0;
			
            $result = mysql_fetch_array($result);
			
			$total_harga = $result["harga"] * $result["jumlah"];
			$subtotal=$subtotal+$total_harga;
			$berat = $berat + $result["berat"]*$result["jumlah"];
			$ongkir =$berat * $result["ongkir"];
			
		
            $member = array();
            $member["id"] = $result["id_order"];
            $member["nama"] = $result["nama_lengkap"];
			$member["uncode"] = $result["un_code"];
			$member["total"] = $subtotal+$ongkir+$result["un_code"];

            $respon["sukses"] = 1;

            $respon["member"] = array();
			
            array_push($respon["member"], $member);

            echo json_encode($respon);
        } else {
            
            $respon["sukses"] = 0;
            $respon["pesan"] = "Tidak ada member";

            echo json_encode($respon);
        }
    } else {
       
        $respon["sukses"] = 0;
        $respon["pesan"] = "tidak ada member";

        echo json_encode($respon);
    }
} else {
    
    $respon["sukses"] = 0;
    $respon["pesan"] = "data belum terisi";

    echo json_encode($respon);
}
?>

