<?php
error_reporting(0);
include 'koneksi.php';

$respon = array();

 if (isset($_POST['username'])) {
 $username = $_POST['username'];

    $result = mysql_query("select * from tbl_komplain where username ='$username'");

	
    if (!empty($result)) {
        
        if (mysql_num_rows($result) > 0) {
		 
            $respon["status"] = array();
           while ($row = mysql_fetch_array($result)) {
	   
            $status = array();
			$status["nama"] = $row["nama"];
            $status["email"] = $row["email"];
			$status["tanggal"] = $row["tanggal"];
	    	$status["komplain"] = $row["pesan"];
	 
            array_push($respon["status"], $status);
 			}
			
            $respon["sukses"] = 1;

            
            echo json_encode($respon);
        } else {
            
            $respon["sukses"] = 0;
            $respon["pesan"] = "Tidak ada data komplain";

            
            echo json_encode($respon);
        }
    } else {
        
        $respon["sukses"] = 0;
        $respon["pesan"] = "Gagal Query";

        
        echo json_encode($respon);
    }
} else {
    
    $respon["sukses"] = 0;
    $respon["pesan"] = "data json tidak terkirim";

    
    echo json_encode($respon);
}
?>

<h1>Komplain</h1> 
	<form action="komplain.php" method="post"> 
	    Username:<br /> 
	    <input type="text" name="username" value="" /> 
	    <br /><br /> 

	    <input type="submit" value="Cari" /> 
	</form>
