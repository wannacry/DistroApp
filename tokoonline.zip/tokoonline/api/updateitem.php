<?php
error_reporting(0);

include 'koneksi.php';

//buat array untuk menampung respon dari JSON
$respon = array();

// cek apakah nilai yang dikirimkan android sudah terisi
if (isset($_POST['idproduk']) && isset($_POST['username']) && isset($_POST['idorder'])&& isset($_POST['keterangan'])&& isset($_POST['qty'])) {
    
    $idorder = $_POST['idorder'];
	$username = $_POST['username'];
    $idproduk = $_POST['idproduk'];
	$keterangan = $_POST['keterangan'];
	$qty =  $_POST['qty'];
	
	$stok = mysql_query("SELECT * from tbl_produk where id_produk='$idproduk'") or die(mysql_error()); 
	 if (mysql_num_rows($stok) > 0) {
		 while($row = mysql_fetch_array($stok)) {
		 $stok = $row["stok"];
		}
	}	
	
	//cek apakah idproduk sudah ada dalam keranjang
    $cari = mysql_query("SELECT * from tbl_order_detail where id_produk='$idproduk' and username='$username' and id_order='$idorder'") or die(mysql_error());
	   // jika data ada (besar dari nol)  //($cari($_POST['qty']) <= $row(["stok"]))
        if ((mysql_num_rows($cari)> 0) && ($qty <= $stok)) {
		$row = mysql_fetch_array($cari);
		$update=mysql_query("UPDATE tbl_order_detail SET keterangan='$keterangan', jumlah = $qty WHERE id_produk='$idproduk' and username='$username' and id_order='$idorder'");
		
		if ($update) {
        // jika sukses diupdate
        $respon["sukses"] = 1;
		$respon["pesan"] = "Data belanja berhasil diupdate.";
       
        // memprint/mencetak JSON respon
        echo json_encode($respon);
    	} else {
		// gagal update data
        $respon["sukses"] = 0;
	 	$respon["pesan"] = "Gagal update belanja.";
       
        // memprint/mencetak JSON respon
        echo json_encode($respon);
        
    } 
	}
		
		else {
    	// jika data tidak terisi/tidak terset
    	$respon["sukses"] = 0;
    	$respon["pesan"] = "data belum terisi";

    	// memprint/mencetak JSON respon
    	echo json_encode($respon);
}

}

?>
<h1>Update Item</h1> 
	<form action="updateitem.php" method="post"> 
	    id produk:<br /> 
	    <input type="text" name="idproduk" value="" /> 
	    <br /><br /> 
		id order:<br /> 
	    <input type="text" name="id_order" value="" /> 
	    <br /><br />  
		qty:<br /> 
	    <input type="text" name="qty" value="" /> 
	    <br /><br />   
	    <input type="submit" value="Cari" /> 
	</form>
