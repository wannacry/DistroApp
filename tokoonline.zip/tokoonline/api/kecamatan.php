<?php
error_reporting(0);
require("koneksi.php");

	$response = array();
    $response["kecamatan"] = array();
	
	$id_kab = $_GET['id_kab'];
    
    // Mysql select query
    $result = mysql_query("SELECT * FROM tbl_kecamatan WHERE id_kabupaten='$id_kab'");
    
    while($row = mysql_fetch_array($result)){
        // temporary array to create tujuan
        $kec = array();
        $kec["id"] = $row["id_kecamatan"];
        $kec["kecamatan"] = $row["nama_kecamatan"];
		$kec["ongkir"] = $row["ongkir"];
        
        // push category to final json array
        array_push($response["kecamatan"], $kec);
    }
    
    // keeping response header to json
    header('Content-Type: application/json');
    
    // echoing json result
	echo json_encode($response); 
	
	?>