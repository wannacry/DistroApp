<?php
error_reporting(0);
require("koneksi.php");

//buat array untuk menampung respon dari JSON
$respon = array();


// cek apakah nilai yang dikirimkan android sudah terisi
 if (isset($_POST['username'])) { //&& isset($_POST['id_order'])
 $username = $_POST['username'];
 //$idorder = $_POST['id_order'];

// query ambil data member berdasarkan idproduk dan id sesi
    $result = mysql_query("SELECT * FROM tbl_order INNER JOIN tbl_order_detail ON tbl_order.id_order = tbl_order_detail.id_order 
INNER JOIN tbl_produk ON tbl_produk.id_produk = tbl_order_detail.id_produk 
WHERE tbl_order.username='$username' AND tbl_order.ket ='1'") or die(mysql_error()); //and K.id_order='$idorder'
	
	
    if (!empty($result)) {
        // jika data jadwal ada (besar dari nol)
        if (mysql_num_rows($result) > 0) {
		$subtotal =0;
		$count =0;
		$berat = 0;
		// node keranjang
            $respon["keranjang"] = array();
            while($row = mysql_fetch_array($result)) {
			
			//$disc        = ($row[diskon]/100)*$row[harga];
			//$hargadisc   = number_format(($row[harga]-$disc),0,",",".");
			$total_harga = $row["harga"] * $row["jumlah"];

			$subtotal=$subtotal+$total_harga;
			$count = $count + $row["jumlah"];
			$berat = $berat + $row["berat"]*$row[jumlah];
		   
			// temp keranjang array
            $keranjang = array();
			$keranjang["id_produk"] = $row["id_produk"];
			$keranjang["idorder"] = $row["id_order"];
			$keranjang["username"] =  $_POST['username'];
			$keranjang["nama"] =  $row["nama_produk"];
            $keranjang["qty"] = $row["jumlah"];
			$keranjang["gambar"] = "http://192.168.43.96/tokoonline/$row[gambar_produk]";
			$keranjang["harga"] = $row["harga"];
			$keranjang["totharga"] = $total_harga;
			          
			//tambahkan array $jadwal pada array final $respon
            array_push($respon["keranjang"], $keranjang);
			}
			// sukses
            $respon["subtotal"] = $subtotal;
			$respon["sukses"] = 1;
			$respon["count"] = $count;
			$respon["berat"] = ceil($berat);
			 
            // memprint/mencetak JSON respon
            echo json_encode($respon);
        } else {
            // tidak ada keranjang (kecil dari nol)
            $respon["sukses"] = 0;
            $respon["pesan"] = "Keranjang Kosong";

            // memprint/mencetak JSON respon
            echo json_encode($respon);
        }
    } else {
        // jika query tidak tidak menghasilkan data (tidak ada member)
        $respon["sukses"] = 0;
        $respon["pesan"] = "Gagal Query";

        // memprint/mencetak JSON respon
        echo json_encode($respon);
    }
} else {
    // jika data tidak terisi/tidak terset
    $respon["sukses"] = 0;
    $respon["pesan"] = "Data json tidak terkirim";

    // memprint/mencetak JSON respon
    echo json_encode($respon);
}
?>
<h1>Cari Keranjang</h1> 
	<form action="keranjang.php" method="post"> 
	    username:<br /> 
	    <input type="text" name="username" value="" /> 
	    <br /><br /> 
		   
	    <input type="submit" value="Cari" /> 
	</form>
