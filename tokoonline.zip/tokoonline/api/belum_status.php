<?php
error_reporting(0);
require("koneksi.php");

$respon = array();

 if (isset($_POST['username'])) {
 $username = $_POST['username'];

    $result = mysql_query("select p.id_order, p.tgl_order, p.jam_order, p.status_order, k.nama_lengkap FROM tbl_order as p, tbl_kustomer as k WHERE p.username='$username' AND p.id_order=k.id_order AND p.status_order='0'");

	
    if (!empty($result)) {
        
        if (mysql_num_rows($result) > 0) {
		 
            $respon["status"] = array();
           while ($row = mysql_fetch_array($result)) {
	   
            $status = array();
            $status["id"] = $row["id_order"];
			$status["nama"] = $row["nama_lengkap"];
            $status["tanggal"] = $row["tgl_order"];
			$status["jam"] = $row["jam_order"];
	 
            array_push($respon["status"], $status);
 			}
			
            $respon["sukses"] = 1;

            
            echo json_encode($respon);
        } else {
            
            $respon["sukses"] = 0;
            $respon["pesan"] = "Tidak ada data pesanan";

            
            echo json_encode($respon);
        }
    } else {
        
        $respon["sukses"] = 0;
        $respon["pesan"] = "Gagal Query";

        
        echo json_encode($respon);
    }
} else {
    
    $respon["sukses"] = 0;
    $respon["pesan"] = "data json tidak terkirim";

    
    echo json_encode($respon);
}
?>

<h1>Cari Jadwal</h1> 
	<form action="cek_status.php" method="post"> 
	    Kota Asal:<br /> 
	    <input type="text" name="username" value="" /> 
	    <br /><br /> 

	    <input type="submit" value="Cari" /> 
	</form>
