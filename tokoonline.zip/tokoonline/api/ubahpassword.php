<?php
error_reporting(0);
require("koneksi.php");
 
$response = array();

if (isset($_POST['username']) && isset($_POST['passbaru'])) {
 
	$username = $_POST['username'];
	$passlama = $_POST['passlama'];
	$password = $_POST['passbaru'];
	
	$cari = mysql_query("SELECT * from tbl_member where username='$username'") or die(mysql_error());
	   // jika data ada (besar dari nol)
    if (mysql_num_rows($cari)> 0) {
	$row = mysql_fetch_array($cari);
	$update=mysql_query("UPDATE tbl_member SET password = '$password' WHERE username = '$username'");
 	if ($update) {
        // jika sukses diupdate
    $response["success"] = 1;
    $response["message"] = "Berhasil mengupdate";
	
	 echo json_encode($respon);
    } else {
	// gagal update data
     $response["success"] = 0;
	 $respon["message"] = "Gagal mengupdate";
       
        // memprint/mencetak JSON respon
        echo json_encode($respon);   
    }
	}
		
		else {
    // jika data tidak terisi/tidak terset
    $response["success"] = 0;
    $response["message"] = "data belum terisi";

    // memprint/mencetak JSON respon
    echo json_encode($response);
}

}
	  
?>
<h1>Update </h1> 
	<form action="changepassword.php" method="post"> 
	    Username:<br /> 
	    <input type="text" name="username" value="" /> 
	    <br /><br /> 
		Password:<br /> 
	    <input type="text" name="password" value="" /> 
	    <br /><br />   
	    <input type="submit" value="update" /> 
	</form>
