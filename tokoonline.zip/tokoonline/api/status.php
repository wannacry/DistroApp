<?php
error_reporting(0);
require("koneksi.php");

$response = array();
 
 if (empty($_POST['jumlah'])) {

    $jumlah = $_POST['jumlah'];
	
	$pencarian = mysql_query("SELECT RIGHT (jumlah, 3) AS kode FROM tbl_konfirmasi WHERE jumlah = '$jumlah'") or die(mysql_error()); 
	 if (mysql_num_rows($pencarian) > 0) {
		 while($row = mysql_fetch_array($pencarian)) {
		 $kode = $row["kode"];
		}
	}
	
	$cek = mysql_query("SELECT * FROM tbl_kustomer WHERE un_code = '$kode'") or die(mysql_error()); 
	 if (mysql_num_rows($cek) > 0) {
		 while($row = mysql_fetch_array($cek)) {
		 $uncode = $row["un_code"];
		 $idorder = $row["id_order"];
		}
	}
	
	$cek_idp=mysql_query("SELECT * FROM tbl_order WHERE id_order = '$idorder'");
	if (mysql_num_rows($cek_idp) > 0) {
	$result = mysql_query("UPDATE tbl_order SET status_order='1' WHERE id_order='$idorder'");
	
	}
    
    if ($result) {
        
       $response["success"] = 1;
       $response["message"] = "Berhasil menyimpan data.";
        
        echo json_encode($response);
    } else {
        
        $response["success"] = 0;
        $response["message"]= "Gagal menambah data.";
        
       
        echo json_encode($response);
  } 
}
  