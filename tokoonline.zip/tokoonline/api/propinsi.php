<?php
error_reporting(0);
require("koneksi.php");
    // array for json response
    $response = array();
    $response["propinsi"] = array();
    
    // Mysql select query
    $result = mysql_query("SELECT * FROM tbl_provinsi");
    
    while($row = mysql_fetch_array($result)){
        // temporary array to create asal
        $propinsi = array();
        $propinsi["id"] = $row["id_provinsi"];
        $propinsi["prop"] = $row["nama"];
        
        // push category to final json array
        array_push($response["propinsi"], $propinsi);
    }
    
    // keeping response header to json
    header('Content-Type: application/json');
    
    // echoing json result
	echo json_encode($response);
	
?>