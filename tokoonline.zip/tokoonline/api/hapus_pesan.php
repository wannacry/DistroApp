<?php
error_reporting(0);
require("koneksi.php");

$respon = array();

if (isset($_GET["username"]) && isset($_GET["id_order"])) {
    $username = $_GET['username'];
	$id_order = $_GET['id_order'];

    $result = mysql_query("SELECT * FROM tbl_order INNER JOIN tbl_order_detail 
	ON tbl_order.id_order = tbl_order_detail.id_order
	INNER JOIN tbl_produk ON tbl_produk.id_produk = tbl_order_detail.id_produk 
	WHERE tbl_order.username='$username' AND tbl_order.ket ='0' AND tbl_order.id_order='$id_order'");

    if (!empty($result)) {

        if (mysql_num_rows($result) > 0) {
			$subtotal =0;
			$count =0;
			$berat = 0;
			
            $result = mysql_fetch_array($result);
		
			$total_harga = $row["harga"] * $row["jumlah"];

			$subtotal=$subtotal+$total_harga;
			$count = $count + $row["jumlah"];
			$berat = $berat + $row["berat"]*$row[jumlah];	
			
            $info = array();
            $info["id_order"] = $result["id_order"];
            $info["username"] = $result["username"];
            $info["totharga"] = $total_harga;

            // sukses
            $respon["sukses"] = 1;

            // node member
            $respon["infoku"] = array();
			//tambahkan array $member pada array final $respon
            array_push($respon["infoku"], $info);

            // memprint/mencetak JSON respon
            echo json_encode($respon);
        } else {
            // tidak ada member (kecil dari nol)
            $respon["sukses"] = 0;
            $respon["pesan"] = "Tidak ada info";

            // memprint/mencetak JSON respon
            echo json_encode($respon);
        }
    } else {
        // jika query tidak tidak meghasilkan data (tidak ada member)
        $respon["sukses"] = 0;
        $respon["pesan"] = "tidak ada info";

        // memprint/mencetak JSON respon
        echo json_encode($respon);
    }
} else {
    // jika data tidak terisi/tidak terset
    $respon["sukses"] = 0;
    $respon["pesan"] = "data belum terisi";

    // memprint/mencetak JSON respon
    echo json_encode($respon);
}
?>

