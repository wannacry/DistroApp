<?php
error_reporting(0);
include 'koneksi.php';
date_default_timezone_set('Asia/Jakarta');

$respon = array();

if (isset($_POST['id_produk']) && isset($_POST['username'])) {
   
    $id_produk= $_POST['id_produk'];
	$username = $_POST['username'];
	$jam = date("H:i:s");
	$tanggal = date("Y-m-d");
	$jumlah=1;
	
	$pencarian = mysql_query("SELECT * from tbl_order where username='$username' and ket='1'") or die(mysql_error()); 
	 if (mysql_num_rows($pencarian) > 0) {
		 while($row = mysql_fetch_array($pencarian)) {
		 $idorder = $row["id_order"];
		}
	}

	$cari = mysql_query("SELECT * from tbl_order_detail where username='$username' and id_produk='$id_produk' and id_order='$idorder'") or die(mysql_error());
	
        // jika data jadwal ada (besar dari nol)
        if (mysql_num_rows($cari) > 0) {
		$update=mysql_query("UPDATE tbl_order_detail SET jumlah = jumlah+1 WHERE id_produk='$id_produk' and username='$username' and id_order='$idorder'");
		if ($update) {
        // jika berhasil menambah data ke mysql
        $respon["sukses"] = 1;
        $respon["pesan"] = "Berhasil update item belanja.";

        // memprint/mencetak JSON respon
        echo json_encode($respon);
    } else {
        // gagal menambah data member
        $respon["sukses"] = 0;
        $respon["pesan"] = "Gagal update item belanja.";
        
        // memprint/mencetak JSON respon
        echo json_encode($respon);
    }
    
	}else {
	  // query menambah data belanja
    $result = mysql_query("INSERT INTO tbl_order_detail(id_order, id_produk, jumlah, username) VALUES('$idorder','$id_produk', '$jumlah', '$username')");
	
    // cek apakah query berhasil menambah data
    if ($result) {
        // jika berhasil menambah data ke mysql
        $respon["sukses"] = 1;
        $respon["pesan"] = "Berhasil menambah data belanja.";

        // memprint/mencetak JSON respon
        echo json_encode($respon);
    } else {
        // gagal menambah data member
        $respon["sukses"] = 0;
        $respon["pesan"] = "Gagal menambah data belanja.";
        
        // memprint/mencetak JSON respon
        echo json_encode($respon);
    }

}
}

?>
<h1>Tambah Keranjang</h1> 
	<form action="tambahkeranjang.php" method="post"> 
	    id produk:<br /> 
	    <input type="text" name="id_produk" value="" /> 
	    <br /><br /> 
		id sesi:<br /> 
	    <input type="text" name="session" value="" /> 
	    <br /><br />   
	    <input type="submit" value="Cari" /> 
	</form>
