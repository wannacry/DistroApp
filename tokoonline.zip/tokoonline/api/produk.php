<?php
	include_once('../includes/connect_database.php'); 
	include_once('../includes/variables.php');
	
	if(isset($_GET['accesskey']) && isset($_GET['category_id'])) {
		$access_key_received = $_GET['accesskey'];
		$category_ID = $_GET['category_id'];
		
		if(isset($_GET['keyword'])){
			$keyword = $_GET['keyword'];
		}else{
			$keyword = "";
		}
		
		if($access_key_received == $access_key){
			if($keyword == ""){
				// find product by category id in product table
				$sql_query = "SELECT id_produk, nama_produk, harga, gambar_produk 
					FROM tbl_produk 
					WHERE id_kategori = ".$category_ID." AND stok > 0
					ORDER BY id_produk DESC";
			}else{
				// find product by category id and keyword in product table
				$sql_query = "SELECT id_produk, nama_produk, harga, gambar_produk 
					FROM tbl_produk 
					WHERE nama_produk LIKE '%".$keyword."%' AND id_kategori = ".$category_ID." AND stok > 0
					ORDER BY id_produk DESC";
			}
			
			$result = $connect->query($sql_query) or die("Error : ".mysql_error());
			
			$products = array();
			while($product = $result->fetch_assoc()) {
				$products[] = array('Product'=>$product);
			}
			
			// create json output
			$output = json_encode(array('data' => $products));
		}else{
			die('accesskey is incorrect.');
		}
	} else {
		die('accesskey and category id are required.');
	}
 
	//Output the output.
	echo $output;

	include_once('../includes/close_database.php'); 
?>