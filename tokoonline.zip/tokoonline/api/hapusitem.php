<?php
//koneksi database mysql
include 'koneksi.php';
error_reporting(0);

//buat array untuk menampung respon dari JSON
$response = array();

// cek apakah variabel idmem sudah terset / terisi
if (isset($_POST['username']) && isset($_POST['id_produk']) && isset($_POST['id_order'])) {
     $username = $_POST['username'];
     $id_produk = $_POST['id_produk'];
	 $id_order = $_POST['id_order'];

    // query update member berdasarkan id
    $result = mysql_query("DELETE FROM tbl_order_detail WHERE id_produk='$id_produk' and username='$username' and id_order='$id_order'");
    
    // jika berhasil di hapus
    if (mysql_affected_rows() > 0) {
        $respon["sukses"] = 1;
        $respon["pesan"] = "Item berhasil dihapus";

        // memprint/mencetak JSON respon
        echo json_encode($respon);
    } else {
        // jika gagal dihapus
        $respon["sukses"] = 0;
        $respon["pesan"] = "Gagal dihapus";

        // memprint/mencetak JSON respon
        echo json_encode($respon);
    }
} else {
    // jika data tidak terisi/tidak terset
    $respon["sukses"] = 0;
    $respon["pesan"] = "data belum terisi";

    // memprint/mencetak JSON respon
    echo json_encode($respon);
}
?>
<h1>Update Item</h1> 
	<form action="hapusitem.php" method="post"> 
	    id produk:<br /> 
	    <input type="text" name="idproduk" value="" /> 
	    <br /><br /> 
		id order:<br /> 
	    <input type="text" name="id_order" value="" /> 
	    <br /><br />  
	    <input type="submit" value="Cari" /> 
	</form>
