<?php
	include_once('../includes/connect_database.php'); 
	include_once('../includes/variables.php');
	
	if(isset($_GET['accesskey']) && isset($_GET['product_id'])) {
		$access_key_received = $_GET['accesskey'];
		$product_ID = $_GET['product_id'];
		
		if($access_key_received == $access_key){
			// get product data from prodct table
			$sql_query = "SELECT id_produk, nama_produk, gambar_produk, harga, status, deskripsi, berat, stok 
				FROM tbl_produk 
				WHERE id_produk = ".$product_ID;
				
			$result = $connect->query($sql_query) or die ("Error :".mysql_error());
	 
			$products = array();
			while($product = $result->fetch_assoc()) {
				$products[] = array('Product_detail'=>$product);
			}
		 
			// create json output
			$output = json_encode(array('data' => $products));
		}else{
			die('accesskey is incorrect.');
		}
	} else {
		die('accesskey and product id are required.');
	}
 
	//Output the output.
	echo $output;

	include_once('../includes/close_database.php'); 
?>