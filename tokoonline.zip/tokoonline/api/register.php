<?php
error_reporting(0);
require("koneksi.php");
 
$response = array();

 
if (empty($_POST['username']) || empty($_POST['password']) || empty($_POST['nama']) || empty($_POST['alamat']) || empty($_POST['telpon']) || empty($_POST['jenkel']) || empty($_POST['email'])) {
 
    $response["success"]= 0;
    $response["message"] = "Pastikan semua data terisi";

   
    echo json_encode($response);	
	}else {
    
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
	$jenkel = $_POST['jenkel'];
	$telpon = $_POST['telpon'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$email = $_POST['email'];
	
	$cek_email=mysql_query("SELECT * FROM tbl_member WHERE username = '$username'");
	if (mysql_num_rows($cek_email) > 0) {
	$response["success"] = 0;
    $response["message"]= "Username sudah pernah terdaftar.";
	echo json_encode($response);
     }
	 if (mysql_num_rows($cek_email) == 0) {
	  
    $result = mysql_query("INSERT INTO tbl_member(nama, alamat, jenkel, telpon, email, username, password) VALUES('$nama','$alamat','$jenkel', '$telpon','$email', '$username', '$password')");
    
    if ($result) {
       
        $response["success"] = 1;
       $response["message"] = "Berhasil menambah data member.";

      
        echo json_encode($response);
    } else {
       
        $response["success"] = 0;
        $response["message"]= "Gagal menambah data.";
        
         
        echo json_encode($response);
  } 
  }
  }
?>
	<h1>Register</h1> 
	<form action="register.php" method="post"> 
	    Username:<br /> 
	    <input type="text" name="username" value="" /> 
	    <br /><br /> 
	    Password:<br /> 
	    <input type="password" name="password" value="" /> 
	    <br /><br /> 
		 <input type="text" name="nama" value="" /> 
	    <br /><br />
		 <input type="text" name="alamat" value="" /> 
	    <br /><br />
		 <input type="text" name="telpon" value="" /> 
		 <br /><br />
		 <input type="text" name="email" value="" /> 
	    <br /><br />
		 Jenis Kelamin:<br />
		  <input type="text" name="jenkel" value="" /> 
	    <br /><br />
	    <input type="submit" value="Register New User" /> 
	</form>