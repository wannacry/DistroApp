<?php
	include($_SERVER['DOCUMENT_ROOT'].'/tokoonline/includes/variables.php');
	$connect->close();
?>