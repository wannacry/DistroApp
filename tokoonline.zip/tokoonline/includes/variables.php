<?php
	//database configuration
	$host ="localhost";
	$user ="root";
	$pass ="";
	$database = "revisi";
	$connect = new mysqli($host, $user, $pass,$database) or die("Error : ".mysql_error());
	
	//access key to access API
	$access_key = "12345";
	
	//google play url
	$gplay_url = "https://play.google.com/store/apps/details?id=your.package.com";
	
	// email configuration
	$admin_email = "demoonlineku@gmail.com";
	$email_subject = "Notifikasi perubahan untuk informasi akun!";
	$change_message = "Kamu sudah merubah info admin kamu, seperti email dan atau password.";
	$reset_message = "Password baru kamu adalah ";
	
	//order notification configuration
	$order_subject = "Notifikasi order baru!";
	$send_order_subject = "Notifikasi konfirmasi order";
	$order_message = "Terdapat order baru yang belum dilihat, mas bro! Silahkan cek di web administrator";
	
	//copyright
	$copyright = "The Distro App &copy; 2016 andridev.com. All rights reserved.";
?>